import 'package:flutter/material.dart';
import 'package:flutter_app/pages/register.dart';
import 'package:flutter_app/provider/regdata.dart';
import 'package:flutter_app/theme.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState(){
    super.initState();
    Provider.of<DataProvider>(context, listen: false).initial();
  }
  @override
  Widget build(BuildContext context) {
    DataProvider dataProvider = Provider.of<DataProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Provider',
          style: whiteTextStyle,
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Consumer<DataProvider>(
              builder: (context, dataProvider, _) {
                return Text(dataProvider.nama);
              },
            ),
            const SizedBox(
              height: 20,
            ),
            Consumer<DataProvider>(
              builder: (context, dataProvider, _) {
                return Text(dataProvider.email);
              },
            ),
            ElevatedButton(
              onPressed: () {
                dataProvider.regisdata.setBool('login', true);
                dataProvider.regisdata.remove('nama');
                dataProvider.regisdata.remove('email');

                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>Register(),
                  ),
                );
              },
              child: Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}
