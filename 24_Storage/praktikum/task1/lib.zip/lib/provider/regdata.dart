import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DataProvider extends ChangeNotifier{
  late SharedPreferences regisdata;
  String nama = '';
  String email = '';

  void initial() async{
    regisdata = await SharedPreferences.getInstance();
    nama = regisdata.getString('nama').toString();
    email = regisdata.getString('email').toString();
    notifyListeners();
  }
}